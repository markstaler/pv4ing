#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
DataAquisition

Created on Thu Oct 11 14:29:53 2018

@author: pi
"""
import comDevice
import time
import datetime as dt
import matplotlib.pyplot as plt
import numpy as np

filename = 'dataFile.csv'
sensor = comDevice.initBME680()
tint = 5 # [sec]

file = open(filename, 'a')
file.write('Tlocal,H,T_pyr,T_bme,prea,humi,resi,T_rpi,\n')  # header
file.close()

try:
    while True:
        time.sleep(5)
        currT = dt.datetime.now()
        temp, prea, humi, resi = comDevice.getBME680(sensor)
        resH, resT = comDevice.comHukse()             
        tempR = comDevice.rpiT()                    
        print(str(currT) + ', ' + \
              str(resH) + 'W/m2, ' + \
              str(resT) + '°C, ' + \
              str(temp) + '°C, ' + \
              str(prea) + 'hPa, ' +  \
              str(humi) + '%, ' + \
              str(int(resi)) + ' 100kOhm, ' + \
              str(tempR) + '°C')

        string =  currT.strftime('%Y-%m-%d %H:%M:%S, ') + \
            str(resH) + ',' + \
            str(resT) + ',' + \
            str(temp) + ',' + \
            str(prea) + ',' +  \
            str(humi) + ',' + \
            str(int(resi)) + ',' + \
            str(tempR) + ',\n'

        file = open(filename, 'a')
        file.write(string)
        file.close()
except KeyboardInterrupt:
    pass

print('...ende')