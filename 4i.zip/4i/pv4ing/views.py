# -*- coding: utf-8 -*-
"""
Created on Thu Jun 28 08:50:37 2018

@author: mark
"""

from django.shortcuts import render, render_to_response
from django.conf import settings
from . import myLib
import datetime as dt


def home(request):
    print('start') 
    
    if request.POST: # get new data from Page
        print('reload...')
        dic    = request.POST 
        if dic['knopf'] == 'aktualisieren 1':
            t0 = dt.datetime.now()
            myLib.rechnen(dic)
            t1 = dt.datetime.now()
            cpuT = (t1 - t0).total_seconds()
            return render(request,  'home.html', {'dic':dic, 'cpuT':cpuT} )
        elif dic['knopf'] == 'aktualisieren 2':
            htmlChart1 = myLib.monitor()                
            return render(request,  'home.html', {'htmlChart1':htmlChart1, 'dic':dic} )
    else:
        dic={
            'aP'    : 2,        # [kWp] Anfang PV-Anlagen Grrösse
            'eP'    : 9,        # [kWp] Ende PV-Anlagen Grrösse
            'aB'    : 2,        # [kWh] Anfang Batterie Grrösse
            'eB'    : 8,        # [kWh] Anfang Batterie Grrösse
            'aziFl' : 0,        # [°] Ausrichtung
            'neig'  : 20,       # [°] Neigung
            'cPV'   : 2000,     # [CHF/kW]
            'cBat'  : 420,      # [CHF/kWh]
            'am'    : 20,       # Amortisationsdauer Jahre
            'i'     : 2,        # Kapitalzins
            'cNetz' : 0.22,     # Netzbezugstarif
            'cRT'   : 0.08,     # Rückspeisetarif
            }
        cpuT = 0
        htmlChart1 = myLib.monitor() 
        return render(request,  'home.html', {'htmlChart1':htmlChart1,'dic':dic, 'cpuT':cpuT} )


    return render(request,  'home.html', {'dic':dic} )