# -*- coding: utf-8 -*-
"""
Created on Fri Jul 20 07:29:49 2018

@author: mark
"""

import matplotlib.pyplot as plt
import numpy as np
import datetime as dt
import pandas # benötigen wir nur für den Exelimport

from bokeh.layouts import gridplot, column
from bokeh.plotting import figure, show, output_file
from bokeh.embed import components


def rechnen(dic):
    """Funktion zur Berechung der Stromkosten
       Ergebnis ist das Speicher eines Diagramm
       dic ist Dictionary mit Eingabewerten
"""  
    tc    = 42 # [°C] NOCT 
    tkMPP = -0.004 # [1] Temperaturkoeffizient (nicht Prozent)
    lg = 9.4728 # [grad] Längengrad
    bg = 47.1733 # [grad] Breitengrad
    al = 0.2    
    noSimPV = 12
    noSimBat = 14

    #aP    = 2 # [kWp] Anfang PV-Anlagen Grrösse
    #eP    = 8  # [kWp] Ende PV-Anlagen Grrösse
    #aB    = 2  # [kWh] Anfang Batterie Grrösse
    #eB    = 8  # [kWh] Anfang Batterie Grrösse
    #aziFl = 0   # [°] Ausrichtung
    #neig  = 20    # [°] Neigung
    #cPV   = 2000     # [CHF/kW]
    #cBat  = 420    # [CHF/kWh]
    #am    = 20      # Amortisationsdauer Jahre
    #i     = 0.02   # Kapitalzins
    #cNetz = 0.22   # Netzbezugstarif
    #cRT   = 0.08     # Rückspeisetarif 
          
    cos  = lambda arg : np.cos(np.deg2rad(arg))
    sin  = lambda arg : np.sin(np.deg2rad(arg))
    acos = lambda arg : np.rad2deg(np.arccos(arg))
    asin = lambda arg : np.rad2deg(np.arcsin(arg))
    
    aP    = float(dic['aP'])  # [kWp] Anfang PV-Anlagen Grrösse
    eP    = float(dic['eP'])  # [kWp] Ende PV-Anlagen Grrösse
    aB    = float(dic['aB'])  # [kWh] Anfang Batterie Grrösse
    eB    = float(dic['eB'])  # [kWh] Anfang Batterie Grrösse
    aziFl = float(dic['aziFl'])   # [°] Ausrichtung
    neig  = float(dic['neig'])    # [°] Neigung
    cPV   = float(dic['cPV'])     # [CHF/kW]
    cBat  = float(dic['cBat'])    # [CHF/kWh]
    am    = float(dic['am'])      # Amortisationsdauer Jahre
    i     = float(dic['i'])/100   # Kapitalzins
    cNetz = float(dic['cNetz'])   # Netzbezugstarif
    cRT   = float(dic['cRT'])     # Rückspeisetarif 

    pSTC_a   = np.linspace(aP,eP,noSimPV) # [kW] Nennleistung PV-Anlage
    batCap_a = np.linspace(aB,eB,noSimBat)  # [kWh] Batteriekapazität
    
    # Datenimport
    df = pandas.read_csv('data/2017_DataExport1h.csv', delimiter=';') # df für Data Frame
    #df = pandas.read_csv('2017_DataExport1h.csv', delimiter=';') # df für Data Frame
    deltaT = 1 # [h]
    
    tutcIn = df['Time'].values
    hGlo = df['hGlo'].values  # Achtung Spaltennamen vollstänig angeben. 
    hDif = df['hDif'].values
    tAmb = df['Tamb'].values
    pLoad = df['Pload'].values  # Verbrauchsprofil
    
    hDif[hDif<0] = 0  # wichtig
    hGlo[hGlo<0] = 0  # wichtig
    hDir = hGlo - hDif
    
    tutc = [] # leere Liste
    for t in range(tutcIn.size):
        tutc.append(dt.datetime.strptime(tutcIn[t], '%Y-%m-%d %H:%M:%S'))
    tutc = np.array(tutc) # umwandeln in ein numpy Array
    
    lfStd = np.zeros(tutc.size)
    for t in range(tutc.size):
        # berechnet laufender Tag im Jahr
        noDay = (tutc[t] - dt.datetime(tutc[0].year, 1, 1, 0)).days 
        # [h] berechnet laufende Stunde im Tag in UTC!
        noHou = tutc[t].hour + (tutc[t].minute)/60.0 + (tutc[t].second)/3600.0 
        lfStd[t] = noDay*24 + noHou

    
    dekl = 23.45*cos(360/(365*24) * (lfStd - 173*24))
    omega = 15*lfStd + lg - 180  # [grad] Stundenwinkel
    omega = np.mod(omega + 180, 360)-180 # [grad] -180 bis 180
    
    h = asin(sin(dekl)*sin(bg) + cos(dekl)*cos(bg)*cos(omega)) #[grad]
    aziNachmittag = acos((sin(h)*sin(bg) - sin(dekl))/cos(h)/cos(bg))
    aziVormittag = -acos((sin(h)*sin(bg) - sin(dekl))/cos(h)/cos(bg))
    azi = (np.sign(omega)+1)/2*aziNachmittag -(np.sign(omega)-1)/2*aziVormittag
    
    h[h<0] = 0 
    
    
    pVer     = pLoad                # [W] Verbrauchsprofil
    cosTheta = cos(neig)*sin(h) + sin(neig)*cos(h)*cos(azi - aziFl)
    cosTheta[cosTheta<0] = 0
    hDifFl = hDif*(1 + cos(neig))/2
    hAlbFl = hGlo*al*(1 - cos(neig))/2
    hDirFl = hDir/np.maximum(sin(h), sin(5))*cosTheta
    hFl = hDirFl + hDifFl + hAlbFl
            
    tm = tAmb + hFl/800*(tc-20) # [°C] Modultemperatur
    rp = tkMPP*(tm-25)          # [1] Reduktion Leistun aufgrund Temperatur
    
    cStr = np.zeros((pSTC_a.size, batCap_a.size))
    
    for pv in range(pSTC_a.size):
        for b in range(batCap_a.size):
            pSTC   = pSTC_a[pv]
            batCap = batCap_a[b]
            pPV = hFl*(1+rp)*pSTC     # [W] elektrische Leistung PV-Anlage. Müsste ergänzt werden mit /1kWm-2    
         
            # Batterie Berechnung
            wBez  = 0    # [kWh] Energie Netzbezug
            wEin  = 0    # [kWh] Energie Netzeinspeisung   
            wBat  = 0    # [kWh] Energie Batteriestand. Annahme das Batterie zu Beginn leer ist
    
            pBedarf = pVer-pPV  # [W] Bedarf ist Verbrauch agzüglich Produktion, jedoch....
            pBedarf[pBedarf<0]=0 #...darf der Wert nicht <0 sein (z.B. wenn PV grösser ist als Verbrauch)
            for p in range(pPV.size):    
                if wBat >= pBedarf[p]*deltaT/1000:
                    wBat = wBat - pBedarf[p]*deltaT/1000    # [kWh]
                else:
                    wBez = wBez + pBedarf[p]*deltaT/1000 - wBat   # [kWh] Jahresnetzbezug
                    wBat  = 0
                pUebersch = np.maximum(pPV[p]-pVer[p], 0) # [W]      
                if wBat <= batCap:
                    eNichtladbar = np.maximum(pUebersch*deltaT/1000 - (batCap-wBat),0) #[kWh]
                    wBat = wBat + pUebersch*deltaT/1000 - eNichtladbar                 #[kWh] 
                    wEin = wEin + eNichtladbar
                else:
                    wEin = wEin + pUebersch*deltaT/1000   # [kWh] Jahresnetzeinspeisung
    
            cAmort = (batCap*cBat+pSTC*cPV)*(1+i)**am*i/((1+i)**am-1)
            cStr[pv,b] = cAmort + wBez*cNetz - wEin*cRT
    
    wLoad = np.sum(pLoad)*deltaT/1000 # [kWh] Jahresverbrauch
            
    # Darstellung
    fig = plt.figure(1, figsize=(9,5))
    X, Y = np.meshgrid(batCap_a, pSTC_a)
    CS = plt.contour(X, Y, cStr/wLoad*100, 10, cmap='summer')
    plt.clabel(CS,inline=1, linewidths=5, fmt='%1.1f')
    plt.title('Stromkosten [Rp/kWh]') 
    plt.ylabel('PV-Anlage [kW]')
    plt.xlabel('Batteriespeicher [kWh]')
    plt.grid(which='both', linestyle='--')
    plt.savefig('pv4ing/static/images/pvbat.PNG', dpi = 90)
    plt.close(fig)


### Testing - Anpassen des Datenfile-Pfads
#dic={
#        'aP'    : '2',        # [kWp] Anfang PV-Anlagen Grrösse
#        'eB'    : '8',        # [kWp] Ende PV-Anlagen Grrösse
#        'aB'    : '2',        # [kWh] Anfang Batterie Grrösse
#        'eB'    : '8',        # [kWh] Anfang Batterie Grrösse
#        'aziFl' : '0',        # [°] Ausrichtung
#        'neig'  : '20',       # [°] Neigung
#        'cPV'   : '1500',     # [CHF/kW]
#        'cBat'  : '400',      # [CHF/kWh]
#        'am'    : '20',       # Amortisationsdauer Jahre
#        'i'     : '0.02',     # Kapitalzins
#        'cNetz' : '0.08',     # Netzbezugstarif
#        'cRT'   : '0.22',     # Rückspeisetarif  
#        }
#rechnen(dic)
    
def monitor():
    x = np.linspace(0, 4*np.pi, 100)
    y = np.sin(x)
    
    TOOLS = "pan,wheel_zoom,box_zoom,reset,save,box_select"
    
    p1 = figure(title="Legend Example", tools=TOOLS, plot_width=800, plot_height=300)
    p1.line(x,   y, legend="sin(x)", color="orange")
    
    p2 = figure(title="Another Legend Example", plot_width=800, plot_height=300)
    p2.line(x, 2*y, legend="2*sin(x)", line_dash=(4, 4), line_color="green", line_width=2)
    p2.x_range = p1.x_range
    
    script1, div1 = components(column(p1, p2)) # generiert html-Code
    htmlChart1 = div1 + script1 
    print(htmlChart1)
#    output_file("legend.html", title="legend.py example")
#    show(column(p1, p2))  # open a browser
    
    return htmlChart1
    