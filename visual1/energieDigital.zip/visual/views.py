from django.shortcuts import render
import numpy as np
import matplotlib.pyplot as plt
from bokeh.plotting import figure
from bokeh.embed import components


def sinusfunction(request):
    if request.POST:  # wenn "Enter" gedrückt wird
        dic = request.POST  # Werte von Page übernehmen
        print('mal sehen was das ist: ' + str(dic))
        nB2S = int(dic['nB2S'])
        nS2B = nB2S
    else:
        nB2S = 2
        nS2B = 4

    x = np.linspace(0, 2 * 3.14 * nB2S, 1000)
    y = np.sin(x)

    plt.plot(x, y)
    filename = 'visual/static/sinus.jpg'
    plt.savefig(filename)
    plt.clf()  # Figure-Objekt schliessen, damit nicht zuviel Objekte auf dem Server laufen

    p1 = figure(height=400, width=1600, background_fill_alpha=0.8, border_fill_alpha=0.8)
    p1.line(x,y)
    p1.toolbar.logo = None
    [script, div] = components(p1)
    htmlCode = script + div

    return render(request, 'home.html', {'nS2B' : nS2B,'nB2S' : nB2S, 'htmlCode' : htmlCode})